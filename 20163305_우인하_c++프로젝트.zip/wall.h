#pragma once
#include <ncurses.h>

chtype wall_letter = '*';
chtype immune_wall_letter = '+';

class Wall
{
public:
	int wall_size = 160;
	int subwall_size[4] = { 0, 10, 20, 31 };
	int subwall_y[4][32] = { {}, {10,11,12,13,14,15,16,17,18,19}, {10,11,12,13,14,15,16,17,18,19,10,11,12,13,14,15,16,17,18,19}, {10,11,12,13,14,15,16,17,18,19,10,11,12,13,14,15,16,17,18,19,10,10,10,10,10,10,10,10,10,10,10} };
	int subwall_x[4][32] = { {}, {10,10,10,10,10,10,10,10,10,10}, {10,10,10,10,10,10,10,10,10,10,40,40,40,40,40,40,40,40,40,40}, {10,10,10,10,10,10,10,10,10,10,40,40,40,40,40,40,40,40,40,40,20,21,22,23,24,25,26,27,28,29,30} };
	WINDOW* win;
	int winmaxY, winmaxX;
	int y[200];
	int x[200];
	Wall() {};
	//Wall(WINDOW* win) {};
	Wall(WINDOW* win, int stage_num);
	virtual void printWall();
};

class ImmuneWall : public Wall
{
public:
	ImmuneWall(WINDOW* win);
	virtual void printWall();
};

// private function

// public function

Wall::Wall(WINDOW* win, int stage_num)
{
	this->win = win;
	wall_size += subwall_size[stage_num];
	int idx = 0;
	getmaxyx(win, winmaxY, winmaxX);

	// Left Border
	for (int i = 0; i < winmaxY; i++, idx++) {
		y[idx] = i;
		x[idx] = 0;
	}

	// Right Border
	for (int i = 0; i < winmaxY; i++, idx++) {
		y[idx] = i;
		x[idx] = winmaxX - 1;
	}

	// Upward Border
	for (int i = 0; i < winmaxX; i++, idx++) {
		y[idx] = 0;
		x[idx] = i;
	}

	// Downward Border
	for (int i = 0; i < winmaxX; i++, idx++) {
		y[idx] = winmaxY - 1;
		x[idx] = i;
	}

	// Extra Wall
	for (int i = 0; i < subwall_size[stage_num]; i++, idx++) {
		y[idx] = subwall_y[stage_num][i];
		x[idx] = subwall_x[stage_num][i];
	}
}

void Wall::printWall()
{
	for (int i = 0; i < wall_size; i++) {
		mvwaddch(win, y[i], x[i], wall_letter);
	}
}

// public function (ImmuneWall)

ImmuneWall::ImmuneWall(WINDOW* win)
{
	this->win = win;
	getmaxyx(win, winmaxY, winmaxX);
}

void ImmuneWall::printWall()
{
	mvwaddch(win, 0, 0, immune_wall_letter);
	mvwaddch(win, winmaxY - 1, 0, immune_wall_letter);
	mvwaddch(win, 0, winmaxX - 1, immune_wall_letter);
	mvwaddch(win, winmaxY - 1, winmaxX - 1, immune_wall_letter);
}
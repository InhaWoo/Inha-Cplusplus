#pragma once
#include <ncurses.h>
#include <cstdlib>
#include <ctime>
#include "snake.h"

extern chtype head_letter, body_letter, blank_letter, wall_letter, immune_wall_letter;
chtype growth_letter = 'G';
chtype poison_letter = 'P';

class fruit
{
private:
	const chtype fruitLetter[2] = { growth_letter, poison_letter };
	int* fruit_y = new int[3];
	int* fruit_x = new int[3];
	int maxY, maxX;
	WINDOW* win;
	int num_fruit = 0;
public:
	fruit(WINDOW* win);
	void makeFruit();
};

// public function

fruit::fruit(WINDOW* win) {
	this->win = win;
	getmaxyx(win, maxY, maxX);
}

void fruit::makeFruit()
{
	if (num_fruit >= 3) {
		mvwaddch(win, fruit_y[0], fruit_x[0], blank_letter);
		fruit_y[0] = fruit_y[1];
		fruit_y[1] = fruit_y[2];
		fruit_x[0] = fruit_x[1];
		fruit_x[1] = fruit_x[2];
		num_fruit = 3;
	}
	else {
		num_fruit++;
	}

	srand((unsigned int)time(NULL));
	int mode = rand() % 2; // 0 : growth, 1 : poison

	while (1) {
		fruit_y[num_fruit - 1] = (unsigned int)rand() % (maxY - 2) + 1;
		fruit_x[num_fruit - 1] = (unsigned int)rand() % (maxX - 2) + 1;
		chtype c = mvwinch(win, fruit_y[num_fruit - 1], fruit_x[num_fruit - 1]) & A_CHARTEXT;
		if (c == blank_letter) {
			break;
		}
	}

	mvwaddch(win, fruit_y[num_fruit - 1], fruit_x[num_fruit - 1], fruitLetter[mode]);
}

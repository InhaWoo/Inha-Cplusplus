#include <string>
#include "snake.h"
#include <ncurses.h>
#include "fruit.h"
#include "wall.h"
#include "gate.h"
#include <unistd.h>

// VS -> sublime 옮길때 주의사항
// Windows.h -> unistd.h
// Sleep(milisecond) -> usleep(microsecond)
// curses.h -> ncurses.h

using namespace std;

extern chtype wall_letter, immune_wall_letter;
extern int init_snake_length;

int main()
{
	initscr();
	resize_term(40, 100);
	noecho();
	cbreak();
	keypad(stdscr, true);
	curs_set(0);

	start_color();
	init_pair(1, COLOR_BLACK, COLOR_WHITE);
	init_pair(2, COLOR_WHITE, COLOR_BLUE);
	init_pair(3, COLOR_WHITE, COLOR_MAGENTA);

	border('|', '|', '-', '-', '*', '*', '*', '*');
	mvprintw(2, 27, "Press any key to start game");
	refresh();

	int win1_max_y = 30, win1_max_x = 50;
	WINDOW* win1 = newwin(win1_max_y, win1_max_x, 5, 8);
	wbkgd(win1, COLOR_PAIR(1));
	wattron(win1, COLOR_PAIR(1));
	wrefresh(win1);
	keypad(win1, true);

	WINDOW* win2 = newwin(18, 27, 5, 64);
	wbkgd(win2, COLOR_PAIR(2));
	wattron(win2, COLOR_PAIR(2));
	mvwprintw(win2, 1, 10, "<SCORE>");
	wrefresh(win2);
	// 뱀길이/최대길이
	mvwprintw(win2, 3, 7, "SNAKE LENGTH");
	mvwaddch(win2, 4, 10, 3 + 48);
	mvwprintw(win2, 4, 12, "/");
	mvwaddch(win2, 4, 14, 6 + 48);
	mvwprintw(win2, 4, 15, "(max)");
	// g열매/미션개수
	mvwprintw(win2, 6, 7, "GROWTH FRUIT");
	mvwaddch(win2, 7, 10, 0 + 48);
	mvwprintw(win2, 7, 12, "/");
	mvwaddch(win2, 7, 14, 4 + 48);
	// w열매/미션개수
	mvwprintw(win2, 9, 7, "POISON FRUIT");
	mvwaddch(win2, 10, 10, 0 + 48);
	mvwprintw(win2, 10, 12, "/");
	mvwaddch(win2, 10, 14, 1 + 48);
	// GATE통과횟수/미션개수
	mvwprintw(win2, 12, 7, "GATE PASSED");
	mvwaddch(win2, 13, 10, 0 + 48);
	mvwprintw(win2, 13, 12, "/");
	mvwaddch(win2, 13, 14, 1 + 48);
	// 시간
	mvwprintw(win2, 15, 11, "TIME");
	mvwaddch(win2, 16, 12, 0 + 48);
	wrefresh(win2);

	WINDOW* win3 = newwin(11, 27, 24, 64);
	wbkgd(win3, COLOR_PAIR(3));
	wattron(win3, COLOR_PAIR(3));
	mvwprintw(win3, 1, 9, "<MISSION>");
	mvwprintw(win3, 3, 4, "SNAKE LENGTH : ( )");
	mvwprintw(win3, 5, 4, "GROWTH FRUIT : ( )");
	mvwprintw(win3, 7, 4, "POISON FRUIT : ( )");
	mvwprintw(win3, 9, 4, "GATE PASSED  : ( )");
	wrefresh(win3);
	refresh();

	unsigned long stage_num = 0;
	int tic = 250; // milisecond
	bool gameover = false;

	chtype hidden_number = wgetch(win1);
	int hidden_stage_number;
	if (hidden_number == '0') {
		hidden_stage_number = 0;
		stage_num =  hidden_stage_number;
	}
	else if (hidden_number == '1') {
		hidden_stage_number = 1;
		stage_num =  hidden_stage_number;
	}
	else if (hidden_number == '2') {
		hidden_stage_number = 2;
		stage_num =  hidden_stage_number;
	}
	else if (hidden_number == '3') {
		hidden_stage_number = 3;
		stage_num =  hidden_stage_number;
	}
	else {
		// do nothing
	}

	// 게임 시작
	while (1) {
		// 스테이지 시작할 때 마다 초기화해야할 변수들
		Wall wl(win1, stage_num);
		Gate ga(win1, &wl, stage_num);
		fruit fr(win1);
		snake sn(win1, &ga, &fr);
		ImmuneWall iwl(win1);
		unsigned long mission_growth_num = 4;
		unsigned long mission_poison_num = 1;
		unsigned long mission_gate_passed_num = 1;
		unsigned long cnt = 0;
		clock_t t_i = clock();

		// stdscr : display stage number
		mvprintw(2, 27, "         Stage :           ");
		mvaddch(2, 44, stage_num + 49);
		refresh();
		// win1 : print wall, snake
		wclear(win1);
		wl.printWall();
		iwl.printWall();
		sn.initPrintSnake();
		wrefresh(win1);

		nodelay(win1, false);
		sn.setInitDirection();

		// win2 : display time
		mvwprintw(win2, 16, 12, "0    ");
		wrefresh(win2);

		// 스테이지 시작
		nodelay(win1, true);
		while (1) {
			// win1 출력
			sn.moveSnake();
			wrefresh(win1);

			// win2 출력
			// 뱀길이/최대길이
			mvwprintw(win2, 3, 7, "SNAKE LENGTH");
			mvwaddch(win2, 4, 10, sn.snake_length + 48);
			mvwprintw(win2, 4, 12, "/");
			mvwaddch(win2, 4, 14, sn.max_length + 48);
			mvwprintw(win2, 4, 15, "(max)");
			// g열매/미션개수
			mvwprintw(win2, 6, 7, "GROWTH FRUIT");
			mvwaddch(win2, 7, 10, sn.growth_num + 48);
			mvwprintw(win2, 7, 12, "/");
			mvwaddch(win2, 7, 14, mission_growth_num + 48);
			// w열매/미션개수
			mvwprintw(win2, 9, 7, "POISON FRUIT");
			mvwaddch(win2, 10, 10, sn.poison_num + 48);
			mvwprintw(win2, 10, 12, "/");
			mvwaddch(win2, 10, 14, mission_poison_num + 48);
			// GATE통과횟수/미션개수
			mvwprintw(win2, 12, 7, "GATE PASSED");
			mvwaddch(win2, 13, 10, sn.gate_passed_num + 48);
			mvwprintw(win2, 13, 12, "/");
			mvwaddch(win2, 13, 14, mission_gate_passed_num + 48);
			// 시간
			mvwprintw(win2, 15, 11, "TIME");
			clock_t t_f = clock();
			string time_string = to_string((unsigned long)tic * cnt / 1000);
			const char* time_to_print = time_string.c_str();
			mvwprintw(win2, 16, 12, time_to_print);
			wrefresh(win2);

			// win3 출력
			mvwprintw(win3, 3, 4, "SNAKE LENGTH : ( )");
			mvwprintw(win3, 5, 4, "GROWTH FRUIT : ( )");
			mvwprintw(win3, 7, 4, "POISON FRUIT : ( )");
			mvwprintw(win3, 9, 4, "GATE PASSED  : ( )");
			if (sn.snake_length == sn.max_length) {
				mvwprintw(win3, 3, 20, "O");
			}
			else {
				mvwprintw(win3, 3, 20, " ");
			}
			if (sn.growth_num >= mission_growth_num) {
				mvwprintw(win3, 5, 20, "O");
			}
			if (sn.poison_num >= mission_poison_num) {
				mvwprintw(win3, 7, 20, "O");
			}
			if (sn.gate_passed_num >= mission_gate_passed_num) {
				mvwprintw(win3, 9, 20, "O");
			}
			wrefresh(win3);

			if (sn.collied) {
				gameover = true;
				break;
			}
			if (sn.snake_length <= init_snake_length - 1) {
				gameover = true;
				break;
			}
			if (sn.snake_length >= sn.max_length && \
				sn.growth_num >= mission_growth_num && \
				sn.poison_num >= mission_poison_num && \
				sn.gate_passed_num >= mission_gate_passed_num) {
				stage_num++;
				break;
			}

			cnt++;
			if (cnt % 20 == 0) {
				fr.makeFruit();
			}
			usleep(tic*1000);
		}

		if (gameover || stage_num >= 4) {
			break;
		}
	}

	if (stage_num >= 4) {
		mvprintw(3, 32, "Congratulations!!");
	}
	else {
		mvprintw(3, 35, "Game Over!!");
	}
	refresh();

	getch();
	getch();
	delwin(win1);
	delwin(win2);
	endwin();
	return 0;
}

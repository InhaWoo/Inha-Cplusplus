#pragma once
#include <ncurses.h>
#include <cstdlib>
#include <ctime>
#include "wall.h"
#include "snake.h"

extern chtype wall_letter;
chtype gate_letter = '#';

class Gate
{
public:
	WINDOW* win;
	int stage_num;
	Wall* wl;
	bool is_snake_passing = false;
	bool gate_exist = false;
	int gate1_idx;
	int gate2_idx;
	int gate_y[2];
	int gate_x[2];
	Gate(WINDOW* win, Wall* pwl, int stage_num);
	void makeGate();
	void destroy();
	int gate_type(int idx);
};

// private function

// public function

Gate::Gate(WINDOW* win, Wall* pwl, int stage_num)
{
	this->win = win;
	this->wl = pwl;
	this->stage_num = stage_num;
}

void Gate::makeGate()
{
	if (is_snake_passing == true || gate_exist == true) {
		// 발동 안됨!
	}
	else {
		// 게이트를 만듬
		gate_exist = true;
		srand((unsigned int)time(NULL));

		while (1) {
			gate1_idx = rand() % wl->wall_size;
			if ((mvwinch(win, wl->y[gate1_idx], wl->x[gate1_idx]) & A_CHARTEXT) != immune_wall_letter) {
				break;
			}
		}
		gate_y[0] = wl->y[gate1_idx];
		gate_x[0] = wl->x[gate1_idx];

		while (1) {
			gate2_idx = rand() % wl->wall_size;
			if (gate2_idx != gate1_idx) {
				if ((mvwinch(win, wl->y[gate2_idx], wl->x[gate2_idx]) & A_CHARTEXT) != immune_wall_letter) {
					break;
				}
			}
		}
		gate_y[1] = wl->y[gate2_idx];
		gate_x[1] = wl->x[gate2_idx];

		mvwaddch(win, gate_y[0], gate_x[0], gate_letter);
		mvwaddch(win, gate_y[1], gate_x[1], gate_letter);
	}
}

void Gate::destroy()
{
	if (is_snake_passing == true) {
		// 발동 안됨!
	}
	else {
		mvwaddch(win, gate_y[0], gate_x[0], wall_letter);
		mvwaddch(win, gate_y[1], gate_x[1], wall_letter);
		gate_exist = false;
	}
}

int Gate::gate_type(int idx)
{
	// 좌벽(1), 우벽(2), 상벽(3), 하벽(4), 좌우벽(5), 상하벽(6). (좌우벽 : 좌우가 안막힌벽), 상하벽 : 상하가 안막힌벽))
	if (gate_x[idx] == 0) {
		return 1;
	}
	else if (gate_x[idx] == wl->winmaxX - 1) {
		return 2;
	}
	else if (gate_y[idx] == 0) {
		return 3;
	}
	else if (gate_y[idx] == wl->winmaxY - 1) {
		return 4;
	}
	else if ((mvwinch(win, gate_y[idx], gate_x[idx] - 1) & A_CHARTEXT) != wall_letter, \
		(mvwinch(win, gate_y[idx], gate_x[idx] + 1) & A_CHARTEXT) != wall_letter) {
		return 5;
	}
	else if ((mvwinch(win, gate_y[idx] - 1, gate_x[idx]) & A_CHARTEXT) != wall_letter, \
		(mvwinch(win, gate_y[idx] + 1, gate_x[idx]) & A_CHARTEXT) != wall_letter) {
		return 6;
	}
	else { // This must not happen......
		return 777;
	}
}

#pragma once
#include <ncurses.h>
#include "gate.h"
#include "fruit.h"

extern chtype growth_letter, poison_letter, wall_letter, immune_wall_letter, gate_letter;
chtype head_letter = 'H';
chtype body_letter = 'B';
chtype blank_letter = ' ';

int init_snake_length = 3;

class snake
{
private:
	WINDOW* win;
	int* p_snake_y = new int[1500]; // this include y,x of head too, and p_s_y,x[0] is always head.
	int* p_snake_x = new int[1500];
	//int head_pair = 100;
	//int body_pair = 200;
	int init_y = 15; // initial_head's y,x
	int init_x = 25;
	int head_y;
	int head_x;
	int direction = KEY_LEFT;
	void printSnake();
	void positionUpdate();
	Gate* ga;
	int gate_index;
	int gate_type[2];
	// bool does_gate_exist = false;
	bool is_passing_gate = false;
	int time_passed_after_snake_passed = 0;
	void change_head_position(int t);
	void change_direction(int t);
	fruit* fr;
public:
	snake(WINDOW* win, Gate* pga, fruit* pfr);
	void initPrintSnake();
	void setInitDirection();
	void moveSnake();
	unsigned long snake_length = init_snake_length; // this is length of 'head(=1)' + 'body(=?)'.
	unsigned long max_length = init_snake_length + 3;
	unsigned long growth_num = 0;
	unsigned long poison_num = 0;
	unsigned long gate_passed_num = 0;
	bool collied = false;
};

// private functions

void snake::printSnake()
{
	//wattron(win, head_pair);
	mvwaddch(win, head_y, head_x, head_letter);
	//wattroff(win, head_pair);
	for (int i = 1; i < snake_length; i++) {
		//wattron(win, body_pair);
		mvwaddch(win, p_snake_y[i], p_snake_x[i], body_letter);
		//wattroff(win, body_pair);
	}
}

void snake::positionUpdate()
{
	for (int i = snake_length - 1; i >= 1; i--) {
		p_snake_y[i] = p_snake_y[i - 1];
		p_snake_x[i] = p_snake_x[i - 1];
	}
	p_snake_y[0] = head_y;
	p_snake_x[0] = head_x;
}

void snake::change_head_position(int t)
{
	head_y = ga->gate_y[1 - gate_index];
	head_x = ga->gate_x[1 - gate_index];

	switch (t)
	{
	case 1:
		head_x++;
		break;
	case 2:
		head_x--;
		break;
	case 3:
		head_y++;
		break;
	case 4:
		head_y--;
		break;
	case 5:
		if (direction == KEY_LEFT || direction == KEY_DOWN) {
			head_x--;
		}
		else {
			head_x++;
		}
		break;
	case 6:
		if (direction == KEY_LEFT || direction == KEY_UP) {
			head_y--;
		}
		else {
			head_y++;
		}
		break;
	default:
		// must not happen!
		break;
	}

}

void snake::change_direction(int t)
{
	switch (t)
	{
	case 1:
		direction = KEY_RIGHT;
		break;
	case 2:
		direction = KEY_LEFT;
		break;
	case 3:
		direction = KEY_DOWN;
		break;
	case 4:
		direction = KEY_UP;
		break;
	case 5:
		if (direction == KEY_LEFT || direction == KEY_DOWN) {
			direction = KEY_LEFT;
		}
		else {
			direction = KEY_RIGHT;
		}
		break;
	case 6:
		if (direction == KEY_LEFT || direction == KEY_UP) {
			direction = KEY_UP;
		}
		else {
			direction = KEY_DOWN;
		}
		break;
	default:
		// must not happen!
		break;
	}
}

// public functions

snake::snake(WINDOW* win, Gate* pga, fruit* pfr)
{
	this->win = win;
	this->ga = pga;
	this->fr = pfr;
	//init_pair(head_pair, COLOR_RED, COLOR_WHITE);
	//init_pair(body_pair, COLOR_GREEN, COLOR_WHITE);
	p_snake_y[0] = init_y;
	p_snake_y[1] = init_y;
	p_snake_y[2] = init_y;
	p_snake_y[3] = init_y;
	p_snake_y[4] = init_y + 1;
	p_snake_y[5] = init_y + 2;
	p_snake_y[6] = init_y + 3;

	p_snake_x[0] = init_x;
	p_snake_x[1] = init_x + 1;
	p_snake_x[2] = init_x + 2;
	p_snake_x[3] = init_x + 3;
	p_snake_x[4] = init_x + 3;
	p_snake_x[5] = init_x + 3;
	p_snake_x[6] = init_x + 3;

	head_y = p_snake_y[0];
	head_x = p_snake_x[0];
}

void snake::initPrintSnake()
{
	printSnake();
}

void snake::setInitDirection()
{
	direction = wgetch(win);
}

void snake::moveSnake()
{
	int to_go = wgetch(win);

	if (to_go == ERR) {
	}
	else {
		direction = to_go;
	}

	switch (direction)
	{
	case KEY_UP:
		head_y--;
		break;
	case KEY_DOWN:
		head_y++;
		break;
	case KEY_LEFT:
		head_x--;
		break;
	case KEY_RIGHT:
		head_x++;
		break;
	default:
		break;
	}

	chtype head_will_go_to = mvwinch(win, head_y, head_x) & A_CHARTEXT;
	if (head_will_go_to == growth_letter) {
		if (snake_length < max_length) {
			snake_length++;
		}
		ga->makeGate();
		growth_num++;
	}
	else if (head_will_go_to == poison_letter) {
		mvwaddch(win, p_snake_y[snake_length - 1], p_snake_x[snake_length - 1], blank_letter);
		snake_length--;
		poison_num++;
	}
	else if (head_will_go_to == wall_letter || head_will_go_to == body_letter || head_will_go_to == immune_wall_letter) {
		collied = true;
	}
	else if (head_will_go_to == gate_letter) {
		// gate에게 지나간다고 알려줌
		ga->is_snake_passing = true;

		// 헤드가 밟은 게이트가 0번째 게이트인지, 1번째 게이트인지 알아내기
		// 헤드가 밟은 게이트의 인덱스 = gate_index
		// 헤드가 안 밟은(그러니까 순간이동해야할) 게이트의 인덱스 = 1-gate_index (becuase gate_index is always 0 or 1)
		if (head_y == ga->gate_y[0] && head_x == ga->gate_x[0]) {
			gate_index = 0;
		}
		else {
			gate_index = 1;
		}

		// 처음 밟은 게이트랑 순간이동할 게이트가 좌벽(1), 우벽(2), 상벽(3), 하벽(4), 좌우벽(5), 상하벽(6)중에 무엇인지 알아야함
		int gate_type[2];
		gate_type[gate_index] = ga->gate_type(gate_index);
		gate_type[1-gate_index] = ga->gate_type(1-gate_index);

		// 헤드가 어디로 순간이동 해야하는지 결정
		change_head_position(gate_type[1-gate_index]);
		
		// 방향이 어떻게 바뀌어야하는지 결정
		change_direction(gate_type[1-gate_index]);

		time_passed_after_snake_passed = snake_length;
		gate_passed_num++;
	}
	else {
	}
	mvwaddch(win, p_snake_y[snake_length - 1], p_snake_x[snake_length - 1], blank_letter);

	if (time_passed_after_snake_passed > 0) {
		time_passed_after_snake_passed--;
		// 게이트 빠져나가면 is_snake_passing을 false로 만들어준다.
		if (time_passed_after_snake_passed == 0) {
			ga->is_snake_passing = false;
			ga->destroy();
		}
	}

	positionUpdate();

	printSnake();
}
